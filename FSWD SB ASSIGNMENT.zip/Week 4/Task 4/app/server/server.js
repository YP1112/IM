// server/server.js

const express = require('express');
const app = express();

// Define GET route /welcome that responds with a JSON message
app.get('/welcome', (req, res) => {
  res.json({ message: "Welcome to Express!" });
});

// Define the port to run the server
const PORT = process.env.PORT || 5000;

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
