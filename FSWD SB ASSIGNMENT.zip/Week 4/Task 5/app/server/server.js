// server/server.js

const express = require('express');
const app = express();

// Middleware to parse JSON bodies
app.use(express.json());

// In-memory array to store users
// Each user has an id, name, and email
let users = [];

// GET /welcome route (as implemented before)
app.get('/welcome', (req, res) => {
  res.json({ message: "Welcome to Express!" });
});

// GET /users - Retrieves all users
app.get('/users', (req, res) => {
  res.json(users);
});

// POST /users - Creates a new user
app.post('/users', (req, res) => {
  const { name, email } = req.body;
  // Simple ID generation based on the last user's id or start at 1
  const id = users.length > 0 ? users[users.length - 1].id + 1 : 1;
  const newUser = { id, name, email };
  users.push(newUser);
  res.status(201).json(newUser);
});

// PUT /users/:id - Updates a user by ID
app.put('/users/:id', (req, res) => {
  const userId = parseInt(req.params.id);
  const { name, email } = req.body;
  
  // Find the index of the user with the given id
  const userIndex = users.findIndex(user => user.id === userId);
  
  if (userIndex === -1) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  // Update the user record
  users[userIndex] = { id: userId, name, email };
  res.json(users[userIndex]);
});

// DELETE /users/:id - Deletes a user by ID
app.delete('/users/:id', (req, res) => {
  const userId = parseInt(req.params.id);
  
  // Find the index of the user to delete
  const userIndex = users.findIndex(user => user.id === userId);
  
  if (userIndex === -1) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  // Remove the user from the array
  const deletedUser = users.splice(userIndex, 1);
  res.json(deletedUser[0]);
});

// Set the port to run the server
const PORT = process.env.PORT || 5000;

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});