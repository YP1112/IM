// client/src/App.js

import React, { useEffect, useState } from 'react';
import './App.css';

function App() {
  const [welcomeMessage, setWelcomeMessage] = useState('');

  useEffect(() => {
    // Fetch the welcome message from the Express backend
    fetch('/welcome')
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then(data => setWelcomeMessage(data.message))
      .catch(error => console.error('Error fetching welcome message:', error));
  }, []);

  return (
    <div className="App">
      <header className="App-header">
        <h1>{welcomeMessage || 'Loading...'}</h1>
      </header>
    </div>
  );
}

export default App;
