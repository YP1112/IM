// frontend/src/App.js

import React, { useEffect, useState } from 'react';

function App() {
  const [products, setProducts] = useState([]);
  const [selected, setSelected] = useState(null);

  // Load product list
  useEffect(() => {
    fetch('http://localhost:5000/api/products')
      .then(res => res.json())
      .then(data => setProducts(data));
  }, []);

  // Fetch product details when one is clicked
  const handleClick = async (id) => {
    const res = await fetch(`http://localhost:5000/api/products/${id}`);
    const data = await res.json();
    setSelected(data);
  };

  return (
    <div style={{ padding: '20px' }}>
      <h1>Product List</h1>
      <ul>
        {products.map(p => (
          <li key={p.id}>
            {p.name}
            <button onClick={() => handleClick(p.id)} style={{ marginLeft: '10px' }}>
              View Details
            </button>
          </li>
        ))}
      </ul>

      {selected && (
        <div style={{ marginTop: '30px' }}>
          <h2>Details</h2>
          <p><strong>Name:</strong> {selected.name}</p>
          <p><strong>Description:</strong> {selected.description}</p>
          <p><strong>Price:</strong> ${selected.price}</p>
        </div>
      )}
    </div>
  );
}

export default App;