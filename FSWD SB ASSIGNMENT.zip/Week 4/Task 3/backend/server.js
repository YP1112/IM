// backend/server.js

const express = require('express');
const cors = require('cors');

const app = express();

// ✅ Middleware to allow cross-origin requests
app.use(cors());

// ✅ Middleware to parse JSON
app.use(express.json());

const products = [
  { id: 1, name: 'Laptop', description: 'Powerful laptop', price: 1500 },
  { id: 2, name: 'Phone', description: 'Smartphone with great camera', price: 800 },
];

// Endpoint to get all products (id & name)
app.get('/api/products', (req, res) => {
  res.json(products.map(p => ({ id: p.id, name: p.name })));
});

// Endpoint to get details of a single product
app.get('/api/products/:id', (req, res) => {
  const product = products.find(p => p.id === parseInt(req.params.id));
  if (product) res.json(product);
  else res.status(404).send('Product not found');
});

// ✅ Example POST route to add new product (just for demonstration)
app.post('/api/products', (req, res) => {
  const { name, description, price } = req.body;
  const newProduct = {
    id: products.length + 1,
    name,
    description,
    price
  };
  products.push(newProduct);
  res.status(201).json(newProduct);
});

app.listen(5000, () => {
  console.log('Backend server running on http://localhost:5000');
});