import { useState } from 'react';
import { Instagram, Facebook, Twitter, Menu, X, ShoppingCart } from 'lucide-react';

// Product data
const products = [
  {
    id: 1,
    name: "Premium Headphones",
    price: 249.99,
    image: "hp.png"
  },
  {
    id: 2,
    name: "Wireless Earbuds",
    price: 129.99,
    image: "we.png"
  },
  {
    id: 3,
    name: "Smart Speaker",
    price: 79.99,
    image: "ss.png"
  },
  {
    id: 4,
    name: "Noise-Cancelling Headphones",
    price: 349.99,
    image: "nch.png"
  },
  {
    id: 5,
    name: "Portable Bluetooth Speaker",
    price: 89.99,
    image: "pbs.png"
  },
  {
    id: 6,
    name: "Pro Gaming Headset",
    price: 199.99,
    image: "pgh.png"
  }
];

// Product Card Component
const ProductCard = ({ product }) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-shadow duration-300">
      <div className="h-48 overflow-hidden">
        <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
      </div>
      <div className="p-4">
        <h3 className="text-lg font-semibold text-gray-800">{product.name}</h3>
        <p className="text-gray-600 mt-1">${product.price.toFixed(2)}</p>
        <button className="mt-3 w-full bg-indigo-600 text-white py-2 rounded-md hover:bg-indigo-700 transition-colors duration-300">
          Add to Cart
        </button>
      </div>
    </div>
  );
};

// Navbar Component
const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <nav className="bg-white shadow-md fixed w-full z-10">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <a href="#" className="text-2xl font-bold text-indigo-600">SoundGear</a>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <a href="#" className="text-gray-700 hover:text-indigo-600 transition-colors">Home</a>
            <a href="#products" className="text-gray-700 hover:text-indigo-600 transition-colors">Products</a>
            <a href="#" className="text-gray-700 hover:text-indigo-600 transition-colors">About</a>
            <a href="#" className="text-gray-700 hover:text-indigo-600 transition-colors">Contact</a>
            <div className="flex items-center">
              <ShoppingCart className="text-gray-700 hover:text-indigo-600 cursor-pointer" />
            </div>
          </div>

          {/* Mobile Navigation Button */}
          <div className="md:hidden flex items-center">
            <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-gray-700">
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Menu */}
        {isMenuOpen && (
          <div className="md:hidden pb-4">
            <div className="flex flex-col space-y-3">
              <a href="#" className="text-gray-700 hover:text-indigo-600 transition-colors py-2">Home</a>
              <a href="#products" className="text-gray-700 hover:text-indigo-600 transition-colors py-2">Products</a>
              <a href="#" className="text-gray-700 hover:text-indigo-600 transition-colors py-2">About</a>
              <a href="#" className="text-gray-700 hover:text-indigo-600 transition-colors py-2">Contact</a>
              <div className="flex items-center py-2">
                <ShoppingCart className="text-gray-700 hover:text-indigo-600 cursor-pointer" />
                <span className="ml-2">Cart</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

// Hero Section Component
const HeroSection = () => {
  return (
    <div className="relative bg-gradient-to-r from-indigo-500 to-purple-600 pt-28 pb-20 md:py-32">
      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-4xl font-extrabold text-white sm:text-5xl md:text-6xl">
            Next-Level Audio Experience
          </h1>
          <p className="mt-3 max-w-md mx-auto text-lg text-indigo-100 sm:text-xl md:mt-5 md:max-w-2xl">
            Discover our collection of premium audio devices that deliver exceptional sound quality and comfort for music lovers and audiophiles.
          </p>
          <div className="mt-6 sm:mt-8">
            <div className="rounded-md shadow">
              <a
                href="#products"
                className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-indigo-600 bg-white hover:bg-gray-100 md:py-4 md:text-lg md:px-10 transition-colors duration-300"
              >
                Shop Now
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Product Section Component
const ProductSection = () => {
  return (
    <div id="products" className="bg-gray-50 py-16 md:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900">Featured Products</h2>
          <p className="mt-4 max-w-2xl mx-auto text-lg text-gray-600">
            Browse our selection of high-quality audio devices for every need
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </div>
  );
};

// Footer Component
const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="col-span-1 md:col-span-2">
            <h3 className="text-xl font-bold text-indigo-400">SoundGear</h3>
            <p className="mt-2 text-gray-400">
              Premium audio devices for exceptional listening experiences.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">About Us</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Products</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Contact</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Support</a></li>
            </ul>
          </div>

          {/* Social Media Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Connect With Us</h3>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Facebook size={24} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Twitter size={24} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Instagram size={24} />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center">
          <p className="text-gray-400">© 2025 SoundGear. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

// Main App Component
export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <HeroSection />
      <ProductSection />
      <Footer />
    </div>
  );
}