// backend/server.js
const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());

const products = [
  { id: 1, name: 'Laptop', description: 'Powerful laptop', price: 1500 },
  { id: 2, name: 'Phone', description: 'Smartphone with great camera', price: 800 },
];

app.get('/api/products', (req, res) => {
  res.json(products.map(p => ({ id: p.id, name: p.name })));
});

app.get('/api/products/:id', (req, res) => {
  const product = products.find(p => p.id === parseInt(req.params.id));
  if (product) res.json(product);
  else res.status(404).send('Product not found');
});

app.listen(5000, () => console.log('Server running on port 5000'));
