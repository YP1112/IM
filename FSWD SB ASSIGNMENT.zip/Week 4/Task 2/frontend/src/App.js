import React, { useEffect, useState } from 'react';

function App() {
  const [products, setProducts] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);

  useEffect(() => {
    fetch('http://localhost:5000/api/products')
      .then(res => res.json())
      .then(data => setProducts(data));
  }, []);

  const handleClick = (id) => {
    fetch(`http://localhost:5000/api/products/${id}`)
      .then(res => res.json())
      .then(data => setSelectedProduct(data));
  };

  return (
    <div style={{ padding: '20px' }}>
      <h1>Product List</h1>
      {products.map(p => (
        <div key={p.id}>
          <span>{p.name}</span>
          <button onClick={() => handleClick(p.id)}>View Details</button>
        </div>
      ))}
      {selectedProduct && (
        <div style={{ marginTop: '20px' }}>
          <h2>Product Details</h2>
          <p><strong>Name:</strong> {selectedProduct.name}</p>
          <p><strong>Description:</strong> {selectedProduct.description}</p>
          <p><strong>Price:</strong> ${selectedProduct.price}</p>
        </div>
      )}
    </div>
  );
}

export default App;
