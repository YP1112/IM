import React from 'react';

const UserCard = ({ name, email }) => {
  return (
    <div className="max-w-md mx-auto p-6 bg-white rounded-lg shadow-md border border-gray-200">
      <h2 className="text-xl font-bold mb-4">User Information</h2>
      <div className="space-y-2">
        <div className="flex items-center">
          <span className="font-medium text-gray-700 w-16">Name:</span>
          <span className="text-gray-800">{name}</span>
        </div>
        <div className="flex items-center">
          <span className="font-medium text-gray-700 w-16">Email:</span>
          <span className="text-gray-800">{email}</span>
        </div>
      </div>
    </div>
  );
};

export default UserCard;