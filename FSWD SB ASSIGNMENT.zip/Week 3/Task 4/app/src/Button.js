import React from 'react';

const Button = ({ text = 'Click Me', onClick }) => {
  const handleClick = () => {
    console.log('Button clicked!');
    if (onClick) onClick();
  };

  return (
    <button
      onClick={handleClick}
      className="bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded transition duration-200"
    >
      {text}
    </button>
  );
};

// Example usage - exported so it can be used
export const ButtonExample = () => {
  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Button Example</h2>
      <Button />
    </div>
  );
};

export default Button;