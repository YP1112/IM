import React, { useState } from 'react';

const TextUpdater = () => {
  const [text, setText] = useState('');

  const handleInputChange = (e) => {
    setText(e.target.value);
  };

  return (
    <div className="flex flex-col items-center p-4">
      <h2 className="text-xl font-bold mb-4">Text Updater</h2>
      <input
        type="text"
        value={text}
        onChange={handleInputChange}
        placeholder="Type something..."
        className="p-2 border border-gray-300 rounded mb-4 w-64"
      />
      <div className="mt-2">
        <h3 className="text-lg font-semibold">Text Preview:</h3>
        <p className="p-2 bg-gray-100 rounded w-64 min-h-8">{text}</p>
      </div>
    </div>
  );
};

export default TextUpdater;